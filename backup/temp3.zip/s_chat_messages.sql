-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 20, 2011 at 09:19 PM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `myhelp`
--

-- --------------------------------------------------------

--
-- Table structure for table `s_chat_messages`
--

CREATE TABLE IF NOT EXISTS `s_chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `when` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `s_chat_messages`
--

INSERT INTO `s_chat_messages` (`id`, `user`, `message`, `when`) VALUES
(1, 'User1', 'hello', 1316534776),
(2, 'User1', 'this is a testing', 1316541907),
(3, 'User1', 'this is a testing', 1316542173),
(4, 'User1', 'this is a testing2', 1316542190),
(5, 'raymondlwhuang', 'this is a testing', 1316547144),
(6, 'raymondlwhuang@yahoo.com', 'this is a testing', 1316547313),
(7, 'raymondlwhuang@yahoo.com', 'this is a testing2', 1316548623),
(8, 'raymondlwhuang', 'this is a testing', 1316550092),
(9, 'raymondlwhuang', 'this is a testing', 1316550195),
(10, 'raymondlwhuang', 'this is line 2', 1316550204),
(11, 'raymondlwhuang', 'this is line 3', 1316550212),
(12, 'raymondlwhuang', 'hello', 1316550230),
(13, 'raymondlwhuang', 'hello', 1316550272),
(14, 'raymondlwhuang', 'this is the last line', 1316550423);

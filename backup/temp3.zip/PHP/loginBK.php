<?php
session_start();
define( "USERNAME", "raymondlwhuang@t.com" );
define( "PASSWORD", "8b142ccc1020d0439aa100d5dcc7b2c6" );
if ( isset( $_POST["submit_x"] ) ) {
  login();
} elseif ( isset( $_GET["action"] ) and $_GET["action"] == "logout" ) {
  logout();
} elseif ( isset( $_SESSION["username"] ) ) {
  displayPage();
} else {
  displayLoginForm();
}

function login() {
  if ( isset( $_POST["username"] ) and isset( $_POST["password"] ) ) {
    if ( $_POST["username"] == USERNAME and MD5(sha1($_POST["password"])) == PASSWORD ) {
      $_SESSION["username"] = USERNAME;
	  $_SESSION["auth"] = "yes";
      session_write_close();
      header( "Location: MyBlog.php" );
    } else {
      displayLoginForm( "Sorry, that e-mail/password not match. Please try again." );
    }
  }
}

function logout() {
  unset( $_SESSION["username"] );
  unset( $_SESSION["auth"] );
  session_write_close();
  header( "Location: login.php" );
}

function displayPage() {
//  displayPageHeader();
  header( "Location: MyBlog.php" );
}

function displayLoginForm( $message="" ) {
  displayPageHeader();
 if ( $message ) echo '<p class="error">' . $message . '</p>' 
?>
	<form name="ValidateUser" method="Post" onsubmit="return formCheck()">
	<table border="0">
	<tbody>
	<tr>
		<td colspan="2" align="center"><img src="../images/Online.jpg" /></td>
	</tr>	
	<tr>
		<td colspan="2" align="center"><b>
		<font face="GILLS SANS MT" color="141654">Welcome to My Site</font></b></td>
	</tr>
	  <td><font face="GILLS SANS MT" color="141654">E-mail:</font></td>  <td>
	<input name="Username" id ="email" size="30" maxlength="50" autocomplete="off" onblur="ValueSet()" onchange="ValueSet()" type="Text"></td>
	</tr>
	<tr>
	  <td><font face="GILLS SANS MT" color="141654">Password:</font></td>  
	  <td><input name="Password" value="" size="30" maxlength="15" autocomplete="off" type="Password"></td>
	</tr>
	<tr>
	  <td colspan="2" align="center"><!--<input name="Submit" value="Submit" type="Submit">-->
	  <input type="image" src="../images/submit.jpg" name="submit" value="submit" height="50px" onClick="return validEMail(document.getElementById('email').value);"></td>
	</tr>
	<tr>
	  <td colspan="2" align="center"><font face="GILLS SANS MT" color="141654"><b>
	Password is case sensitive.<br> 
	Need help? Please send e-mail to:<br> raymondlwhuang@yahoo.com.</b></font></td>
	</tr>	
	</tbody></table>
	</form>
	
	</center>
	

<center>
<font face="GILLS SANS MT" color="141654"><b>
	*This site is for use of my friend and familly.<br> 
	New user, Please <a href="http://www.raymondlwhuang.com/PHP/NewUser.php">register here</a></b></font><br/>
<b><font color="red" id="ErrorMessage" size="4"></font></b>	
</center>
 
</div>
</body>
</html>
<?php
}

function displayPageHeader() {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="refresh" content="3600">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
<script language="JavaScript">
function formCheck( )	  
{
		if (document.ValidateUser.Username.value == "") 
		{  
		   document.getElementById("ErrorMessage").innerHTML = "Invalid e-mail address!";
		   return false;
		}
		if (document.ValidateUser.Password.value == "") 
		{  
           document.getElementById("ErrorMessage").innerHTML = "You must supply a Password!";
		   return false;
		}
}
function ValueSet( )	  
{
document.ValidateUser.Password.value = "";
}
window.onload = maxWindow;

function maxWindow()
{
window.moveTo(0,0);


if (document.all)
{
  top.window.resizeTo(screen.availWidth,screen.availHeight);
}

else if (document.layers||document.getElementById)
{
  if (top.window.outerHeight<screen.availHeight||top.window.outerWidth<screen.availWidth)
  {
    top.window.outerHeight = screen.availHeight;
    top.window.outerWidth = screen.availWidth;
  }
}
document.ValidateUser.Username.focus();
}
function validEMail(email) {
	var re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if (!re.test(email)){
		document.getElementById("ErrorMessage").innerHTML = "Invalid e-mail address!";
		document.getElementById("email").focus(); 
	}
	return re.test(email);			
}	
</script>

<title>User Login</title>

<style type="text/css">
#mydiv {
	position:absolute;
	top: 50%;
	left: 50%;
	width:330px;
	height:380px;
	margin-top: -300px; /*set to a negative number 1/2 of your height*/
	margin-left: -140px; /*set to a negative number 1/2 of your width*/
	background-color: #FFFFFF;
}
body {
background-image:url('../images/Desert.jpg');
}
</style>


</head>
<body leftmargin="0" topmargin="0" onload="maxWindow()" marginheight="0" marginwidth="0" text="#000000" background="login_files/water_drops_bkg.gif" bgcolor="#FFFFFF">
<div id="mydiv">
	<center>

<?php
}
?>
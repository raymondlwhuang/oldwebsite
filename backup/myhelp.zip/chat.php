<iframe src="messages.html" width="400px" height="280px">
<p>Your browser does not support iframes.</p>
</iframe><br/>
<iframe src="main.php" width="400px" height="60px" frameborder=1 SCROLLING=no>
<p>Your browser does not support iframes.</p>
</iframe>
<?php
include("config.php");
if(isset($_COOKIE['searchID2']) or isset($_REQUEST['searchID2']))
{
	if(isset($_COOKIE['searchID2'])) {$searchID2=(int)$_COOKIE['searchID2'];}
	ELSEIF(isset($_REQUEST['searchID2'])){$searchID2=(int)$_REQUEST['searchID2'];}
	$GetDisplay = "SELECT *	FROM main WHERE id = $searchID2 ORDER BY id LIMIT 1";
	include("RecordSet.php");
	setcookie("searchID2","",time() + 3600);
 }
ELSEIF(isset($_POST['searchID']))
{
	$searchID2 = (int)$_POST['searchID'];
	$GetDisplay = "SELECT * FROM main WHERE id = $searchID2 ORDER BY id  LIMIT 1";
	include("RecordSet.php");
}

$dirPath = "./images/";

function traverseDir( $dir ) {
  if ( !( $handle = opendir( $dir ) ) ) die( "Cannot open $dir." );
  $files = array();
  while ( $file = readdir( $handle ) ) {
    if ( $file != "." && $file != ".." ) {
      if ( is_dir( $dir . "/" . $file ) ) $file .= "/";
      $files[] = $file;
    }
  }
  sort( $files );
?>
<script type="text/javascript">
    var j = <?php echo count($files); ?>;
	var adImages = new Array(j);
	var i = 0;
</script>
<?php
  foreach ( $files as $file ) {
?>
<script type="text/javascript">
adImages[i] = "../images/<?php echo $file; ?>";
i++;
</script>
<?php
	  foreach ( $files as $file ) {
		if ( substr( $file, -1 )  == "/" ) traverseDir( "$dir/" . substr( $file, 0, -1 ) );
	  }
  };
  closedir( $handle );
}
traverseDir( $dirPath );
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script src="http://html5media.googlecode.com/svn/trunk/src/jquery.html5media.min.js"></script>
<script type="text/javascript">
function setnametorun() {
	var text = document.getElementById('Ext').value;
	if(text == "php") var value = "PHP/"+document.getElementById("Name").value+'.'+text;
	else var value = "HTML/"+document.getElementById("Name").value+'.'+text;
	if(text == "php" || text == "html" || text == "pdf") document.getElementById('loaddisp').src = value;
	else if(text == "link") window.open(document.getElementById("Source").innerHTML);
	else  window.open('HTML/Resume.htm');
}
</script>
<link type="text/css" rel="stylesheet" href="css/MyResource.css" />
<script type="text/javascript" src="scripts/passVarToPhp.js"></script>

<meta http-equiv="Content-Type" content="text/html;charset=ISO-8859-1">
<title>My Help Center</title>
<script type="text/javascript" src="scripts/movingtitle.js"></script>
<script type="text/javascript" src="../scripts/ImageRotate.js"></script>
<style type="text/css">
textarea { width: 100%; margin: 0; padding: 1%; border: 1px solid #38c; }
</style>
</head>
<body>
<form name="DescSearch" method="POST">
<input type="hidden" name="searchID" id="searchID"  value="<?php if (isset($searchID)){ echo $searchID; } else ''; ?>"/>
<div align="left">
  <table border="0">
    <tr>
      <td><p>SEARCH:</p></td>
      <td><input type="text"  id="searchField" autocomplete="off" name="ShortDesc" size="90"  maxlength="200" id="ShortDesc" style="border: 1px solid #38c;" onFocus = "clearChoice();" onKeyUp="SendRequest('SearchShortDesc.php',document.getElementById('SearchGroup').value);" /></td>
      <td><img id="loader" src="images/loader.gif" style="vertical-align: middle; display: none" />
	  <input type="hidden" name="Submit" id="searchDone" value="Search" style="background : #AFDCEC ; width : 5em ;color:#04B404;"></td>
    </tr>
    <tr>
    <td colspan="3" align="left"><div id="popups"> </div></td>
    </tr>
  </table>
  </div>
</form>
<table width="100%">
<tr>
<td width="50%" rowspan="2">
<form action="<?php echo $_SERVER['SCRIPT_NAME']; ?>" name="MyForm" enctype="application/x-www-form-urlencoded" method="post">
<table width="100%">
  <tr>
	<td colspan="6"></td>
  </tr>
  <tr>
    <td><p></p></td>
    <td colspan="5"><input type="text" name="ShortDesc" size="100" maxlength="200" style="font-weight:bold;border: 0px #38c;position : fixed ; top: 2em ; right: 2em;text-align:right"  value="<?php if (isset($ShortDesc)){ echo htmlspecialchars($ShortDesc); } else ''; ?>" readonly="readonly"></td>
    </tr>
	<tr>
    <td colspan="6">
	<div class="container">
    <label class="textareaContainer">
	<textarea name="Source" id="Source" rows="35" readonly="readonly"><?php if (isset($Source)){ echo trim(htmlspecialchars($Source)); } else ''; ?></textarea>
	</label>
	</div>
	</td>	
   </tr>
  <tr>
    <td>
	<select name="SearchGroup" id="SearchGroup" class="reqd" >
	   <option value="" <?php if(isset($SearchGroup) && htmlspecialchars($SearchGroup) == "") echo "selected"; ?>>ALL</option>
	   <option value="php" <?php if(isset($SearchGroup) && htmlspecialchars($SearchGroup) == "php") echo "selected"; ?>>php</option>
	   <option value="phpmenu" <?php if(isset($SearchGroup) && htmlspecialchars($SearchGroup) == "phpmenu") echo "selected"; ?>>php menu</option>
	   <option value="html" <?php if(isset($SearchGroup) && htmlspecialchars($SearchGroup) == "html") echo "selected"; ?>>html</option>
	   <option value="htm" <?php if(isset($SearchGroup) && htmlspecialchars($SearchGroup) == "htm") echo "selected"; ?>>htm</option>
	   <option value="pdf" <?php if(isset($SearchGroup) && htmlspecialchars($SearchGroup) == "pdf") echo "selected"; ?>>pdf</option>
	   <option value="js" <?php if(isset($SearchGroup) && htmlspecialchars($SearchGroup) == "js") echo "selected"; ?>>js</option>
	   <option value="txt" <?php if(isset($SearchGroup) && htmlspecialchars($SearchGroup) == "txt") echo "selected"; ?>>txt</option>
	   <option value="link" <?php if(isset($SearchGroup) && htmlspecialchars($SearchGroup) == "link") echo "selected"; ?>>link</option>
	 </select>		
	</td>
    <td align="right"><p></p></td>
    <td width="20"><input type="hidden" name="Name" id="Name" size="15" maxlength="50" style="border: 1px solid #38c;"  value="<?php if (isset($Name)){ echo htmlspecialchars($Name); } else ''; ?>"></td>
    <td align="left" width="10"><p></p></td>
    <td align="left" width="20">
		<input type="hidden" name="Ext" id = "Ext" size="100" maxlength="200" style="border: 1px solid #38c;"  value="<?php if (isset($Ext)){ echo htmlspecialchars($Ext); } else ''; ?>">
	</td>
	<td align="left" width="15"><p></p></td>
</tr>  
</table>    
</form>
</td>
<td width="50%" align="right" valign="top" >
<iframe src="HTML/Resume.htm" id="loaddisp" width="98%" style="margin-top:10px;">
  <p>Your browser does not support iframes.</p>
</iframe>
</td>
<td  align="right" valign="top">
<video src="http://localhost:8380/images/movie.mp4" width="320" height="240" autoplay=true controls autobuffer></video>
</td>
</tr>
<tr>
<td align="center">
<img src="../images/0.png" id="adBanner" alt="Ad Banner" />
</td>
</tr>
</table>
<iframe src="http://raymondlwhuang.host56.com/MyHelpFile.php" width="40%" height="25%" style="position : fixed ; bottom: 2px ; left: 2px ;z-index:-1">
  <p>Your browser does not support iframes.</p>
</iframe>
</body>
</html>
<script type="text/javascript">
	var text = document.getElementById('Ext').value;
	if(text == "php") var value = "PHP/"+document.getElementById("Name").value+'.'+text;
	else var value = "HTML/"+document.getElementById("Name").value+'.'+text;
	if(text == "php" || text == "html" || text == "pdf") document.getElementById('loaddisp').src = value;
	else if(text == "link") window.open(document.getElementById("Source").innerHTML);
</script>
		
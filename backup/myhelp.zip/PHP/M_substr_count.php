<?php
echo 'substr_count("Hello world. The world is nice","world");';
echo "<br/>";
echo substr_count("Hello world. The world is nice","world");
echo "<br/>";
?> 
		
<?php
session_start();
if(@$_SESSION['private'] != "yes")
{
	header('Location: login.php');
	exit();
}
include("../config.php");
include("../inc/GlobalVar.inc.php");

$is_active = 1;
$allow_viewer_upload = 0;
if (get_magic_quotes_gpc())
{
    function _stripslashes_rcurs($variable, $top = true)
    {
        $clean_data = array();
        foreach ($variable as $key => $value)
        {
            $key = ($top) ? $key : stripslashes($key);
            $clean_data[$key] = (is_array($value)) ?
                stripslashes_rcurs($value, false) : stripslashes($value);
        }
        return $clean_data;
    }
    $_GET = _stripslashes_rcurs($_GET);
    $_POST = _stripslashes_rcurs($_POST);
}
if(isset($_POST['Save']))
{
	if(isset($_POST['is_active']))	$is_active =  (int)mysql_real_escape_string($_POST['is_active']);
	else $is_active = 0;
	if(isset($_POST['allow_viewer_upload']))	$allow_viewer_upload =  (int)mysql_real_escape_string($_POST['allow_viewer_upload']);
	else $allow_viewer_upload = 0;
	$viewer_group =  mysql_real_escape_string($_POST['viewer_group']);
	$viewer_email =  mysql_real_escape_string($_POST['viewer_email']);
	if(!filter_var((String) $viewer_email, FILTER_VALIDATE_EMAIL)) {
		$ErrorMessage = "** Invalide e-mail address! Please try again. **";
	}
	else if($GV_email_address == $viewer_email) {
		$viewer_email = $GV_email_address;
		$ErrorMessage = "**You don't have to set permission for yourself! **";
	}
	else {
		$SaveCheck2 = "SELECT * FROM view_permission WHERE owner_email = '$GV_email_address' AND viewer_email = '$viewer_email' and viewer_group = '$viewer_group' LIMIT 1";
		$result2 = mysql_query($SaveCheck2);
		if (mysql_num_rows($result2) > 0){
				$ErrorMessage = "**This is an existing email: $viewer_email! Please try again. **";
		}
		ELSE {
			$SaveCheck3 = "SELECT * FROM viewer_group WHERE owner_path = '$GV_owner_path' AND viewer_group = '$viewer_group' LIMIT 1";
			$result3 = mysql_query($SaveCheck3);
			if (mysql_num_rows($result3) > 0){
				mysql_query("UPDATE viewer_group SET allow_viewer_upload=$allow_viewer_upload WHERE owner_path = '$GV_owner_path' AND viewer_group = '$viewer_group'");
			}
			else {
				mysql_query("INSERT INTO viewer_group(owner_path,viewer_group,allow_viewer_upload) VALUES('$GV_owner_path', '$viewer_group', $allow_viewer_upload)");
			}
			$SaveCheck4 = "SELECT * FROM user WHERE email_address = '$viewer_email' LIMIT 1";
			$result4 = mysql_query($SaveCheck4);
			if (mysql_num_rows($result4) == 0){
				mysql_query("INSERT INTO user(email_address) VALUES('$viewer_email')");
			echo mysql_error(); 
			}			
			mysql_query("INSERT INTO view_permission(owner_email,owner_path,viewer_group,is_active,viewer_email) VALUES('$GV_email_address', '$GV_owner_path', '$viewer_group', $is_active,'$viewer_email')");
			$GetDisplay = "SELECT * FROM view_permission order by id DESC LIMIT 1";
			include("../inc/PermissionControl.inc.php");
			echo mysql_error(); 
			mysql_close();
			
			$inTwoMonths = 60 * 60 * 24 * 60 + time();
			setcookie( "searchID2", $searchID, $inTwoMonths, "", "", false, true );
			$_SESSION["searchID2"] = $searchID;
			 Header("Location: AddPermission.php");
			 die;
		}
	}
}
$query="SELECT * FROM view_permission where owner_email = '$GV_email_address'";  // query string stored in a variable
$ViewerList=mysql_query($query);          // query executed 
echo mysql_error();              // if any error is there that will be printed to the screen 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Adding My Viewer Permission</title>
<script language="JavaScript">
var owner_path = "<?php echo $GV_owner_path; ?>";
function formCheck(email)	  
{
	if (document.ValidateUser.viewer_email.value == "") 
	{  
	   document.getElementById("ErrorMessage").innerHTML = "Invalid e-mail address!Please try again.";
	   return false;
	}
	else {
		var re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		if (!re.test(email)){
			document.getElementById("ErrorMessage").innerHTML = "Invalid e-mail address!Please try again.";
		return re.test(email);			
		}
	}
	if (document.ValidateUser.viewer_group.value == "") 
	{  
	   document.getElementById("ErrorMessage").innerHTML = "Please fill in the viewer group";
	   return false;
	}
	return true;
}

</script>
<script type="text/javascript" src="../scripts/passVarToPhp3.js"></script>
<style type="text/css">
.suggestions {
	background-color: #FF9;
	padding: 2px 6px;
	border: 1px solid #000;
}

.suggestions:hover {
	background-color: #69F;
}
#popups {
	display: none;
	padding: 5px;
	border: 1px #CC0 solid;
	clip: auto;
	overflow: hidden;	
}
#searchField.error {
	background-color: #FFC;
}
</style>
</head>
<body style="color:darkblue;">
<form name="ValidateUser" method="Post">
<input type="hidden" name="owner_email"  class="owner_email" value="<?php if (isset($GV_email_address)){ echo htmlspecialchars($GV_email_address); } else ''; ?>">
<table>
	<tr>
    <td align="right" colspan="2">
	Friend's Email:<input type="text" name="viewer_email" id="viewer_email" size="45"  value="<?php if (isset($viewer_email)){ echo htmlspecialchars($viewer_email); } else ''; ?>">
	</td>
	</tr>
	<tr>
    <td align="right" colspan="2">Group: <input type="text"  id="searchField" autocomplete="off" name="viewer_group" size="45" maxlength="30" id="viewer_group" style="border: 1px solid #38c;" onKeyUp="this.value=this.value.trim();SendRequest('../search/ViewerGroup.php',this.value +':::'+owner_path);"/></td>
	</tr>
	<tr>
    <td align="left">
	Permission?:	<INPUT TYPE="checkbox" NAME="is_active" VALUE="1" <?php if ($is_active == 1){ echo 'checked'; } else echo ''; ?>>
	</td>
    <td align="left">
	Friend Uploadable?: <INPUT TYPE="checkbox" NAME="allow_viewer_upload" id="allow_viewer_upload" VALUE="1" <?php if ($allow_viewer_upload == 1){ echo 'checked'; } else echo ''; ?>>
	</td>
   </tr>    
    <tr>
    <td colspan="3" align="left"><div id="popups"> </div></td>
    </tr>
</table>    
<input type ="submit" name="Save" value="Save"  onClick="return formCheck(document.getElementById('viewer_email').value);">
<input type ="submit" name="Cancel" value="Cancel" onclick="this.form.reset();window.open( '../PHP/PermissionControl.php', 'Permission');return false;">
<input type ="submit" name="Delete" value="Delete" disabled="disabled">
<input type ="submit" name="Add" value="Add" width="190px" disabled="disabled"><br/>
<input type ="submit" name="First" value="First" disabled="disabled"> 
<input type ="submit" name="Previous" value="Previous" disabled="disabled"> 
<input type ="submit" name="Next" value="Next" disabled="disabled"> 
<input type ="submit" name="Last" value="Last" disabled="disabled"> 
<!--<input type ="button" name="Upload" value="Upload Photos/Videos"  disabled="disabled" > -->
<p text-align="right" >	<b><font color=red id="ErrorMessage"><?php if (isset($ErrorMessage)) { echo $ErrorMessage; } else echo 'Viewer Group must be a single word<br/>(will avaliable to all group if leave it blank)'; ?> </font></b>	</p>
</form>
<table border="1">
	<tr>
		<th align='left'>
		Friend's Email
		</th>	
		<th align='left'>
		Group
		</th>	
		<th>
		Permission
		</th>
		<th>
		Friend Uploadable?
		</th>
	</tr>
<?php	
while($nt=mysql_fetch_array($ViewerList)){
$Group="SELECT allow_viewer_upload FROM viewer_group where owner_path = '$GV_owner_path' and viewer_group = '$nt[viewer_group]'";  // query string stored in a variable
$allowed=mysql_query($Group);          // query executed 
echo "
<tr>
    <td align='left'>
	$nt[viewer_email]
	</td>
    <td align='left'>
	$nt[viewer_group]
	</td>
	<td align='center'>
	
	";
	if ($nt['is_active'] == '1') echo "Yes";
	ELSE echo "No";
echo "</td><td align='center'>";
	while($nt2=mysql_fetch_array($allowed)){
		if ($nt2['allow_viewer_upload'] == '1') echo "Yes";
		ELSE echo "No";
	}	
echo "</td></tr>
";
}
?>
</table>
	
<script language="JavaScript">
window.open( "MyBlogUpload.php", "Upload");
document.getElementById("viewer_email").focus();
</script>	
</body>
</html>
	
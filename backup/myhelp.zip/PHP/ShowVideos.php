<?php
session_start();
if(@$_SESSION['private'] != "yes")
{
	header('Location: login.php');
	exit();
}
if (get_magic_quotes_gpc())
{
    function _stripslashes_rcurs($variable, $top = true)
    {
        $clean_data = array();
        foreach ($variable as $key => $value)
        {
            $key = ($top) ? $key : stripslashes($key);
            $clean_data[$key] = (is_array($value)) ?
                stripslashes_rcurs($value, false) : stripslashes($value);
        }
        return $clean_data;
    }
    $_GET = _stripslashes_rcurs($_GET);
    $_POST = _stripslashes_rcurs($_POST);
}
include("../config.php");
include("../inc/GlobalVar.inc.php");
$profile_picture[$GV_owner_path] = $GV_profile_picture;
if(isset($_GET['FriendEmail']))
{
	if($_GET['FriendEmail'] == 'Public') {
		$Picked['Public'] = 'Public';
	}
	else if($_GET['FriendEmail'] == "$GV_email_address") {
			$queryPermission="SELECT * FROM view_permission where owner_email = '$GV_email_address' group by viewer_group";  // query string stored in a variable
			$resultPermission=mysql_query($queryPermission);          // query executed 
			echo mysql_error();              // if any error is there that will be printed to the screen 
			while($row2 = mysql_fetch_array($resultPermission))
			{
			 $viewer_group = $row2['viewer_group'];
			 $GV_owner_path = $row2['owner_path'];
			 $Picked[$GV_owner_path] = $viewer_group;
			}
		}	
	else {
			$FriendEmail = $_GET['FriendEmail'];
			$queryPermission="SELECT * FROM view_permission where owner_email = '$FriendEmail' and viewer_email = '$GV_email_address' order by owner_path";  // query string stored in a variable
			$resultPermission=mysql_query($queryPermission);          // query executed 
			echo mysql_error();              // if any error is there that will be printed to the screen 
			while($row2 = mysql_fetch_array($resultPermission))
			{
			 $viewer_group = $row2['viewer_group'];
			 $owner_path = $row2['owner_path'];
			 $Picked[$owner_path] = $viewer_group;
			} 
			$queryOwner4="SELECT * FROM user where  email_address = '$FriendEmail' order by id DESC LIMIT 1";
			$owner4=mysql_query($queryOwner4);          // query executed 
			echo mysql_error();
			while($row4 = mysql_fetch_array($owner4))
			{
			 $profile_picture[$owner_path] = $row4['profile_picture'];
			} 			
			
		}
}
else {
		$queryPermission="SELECT * FROM view_permission where owner_email = '$GV_email_address' group by viewer_group";  // query string stored in a variable
		$resultPermission=mysql_query($queryPermission);          // query executed 
		echo mysql_error();              // if any error is there that will be printed to the screen 
		while($row2 = mysql_fetch_array($resultPermission))
		{
		 $viewer_group = $row2['viewer_group'];
		 $owner_path = $row2['owner_path'];
		 $Picked[$owner_path] = $viewer_group;
		}
}

 ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html class="cufon-active cufon-ready">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>My Blog</title>
<script type="text/javascript" src="../scripts/fancydropdown.js"></script>
<script type="text/javascript" src="../scripts/jquery.cycle.all.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$('#slider-container').cycle({
        fx:     'uncover',
        speed:  1000,
        timeout: 7000,
		pause:	1,
        pager:  '#banner-nav'
	});
});
</script>
</head>
<body><center>
<?php	
	foreach ($Picked as $key => $value) {
	$countimg = 0;
		if($key !='Public') {
			$query="SELECT * FROM picture_video where owner_path = '$key' and picture_video = 'pictures' and viewer_group = '$value'";  // query string stored in a variable
			$result=mysql_query($query);          // query executed 
			echo mysql_error();              // if any error is there that will be printed to the screen 
		echo '<div style="overflow: hidden;" id="slider-container">';
			if(mysql_num_rows($result) <= 1) {
			  $countimg++;
			  $content ='<div style="display: none; opacity: 1;height: 530px;" id="banner'."$countimg".'">';
			  $content = "$content"."<img src='$profile_picture[$key]' height='60%' usemap='#mail-info' border='0'><br />
			  Your Comments: <input type='text' name='comment' size='48' value =''><br />
			  <textarea rows='8' cols='50' readonly='readonly'>
	 At W3Schools you will find all the Web-building tutorials you need, from basic HTML to advanced XML, SQL, ASP, and PHP. 
	</textarea>";
			  $content = "$content".'</div>';
			  echo "$content";			
			}
			while($row3 = mysql_fetch_array($result))
			{
		  $countimg++;
		  $content ='<div style="display: none; opacity: 1;height: 530px;" id="banner'."$countimg".'">';
		  $content = "$content"."<img src='$row3[name]' height='60%' usemap='#mail-info' border='0'><br />
		  Your Comments: <input type='text' name='comment' size='48' value =''><br />
		  <textarea rows='8' cols='50' readonly='readonly'>
 At W3Schools you will find all the Web-building tutorials you need, from basic HTML to advanced XML, SQL, ASP, and PHP. 
</textarea>";
		  $content = "$content".'</div>';
		  echo "$content";
		  };
		echo '</div>';				
		}
		else {
			$query="SELECT * FROM picture_video where picture_video = 'pictures' and viewer_group = 'Public'";  // query string stored in a variable
			$result=mysql_query($query);          // query executed 
			echo mysql_error();              // if any error is there that will be printed to the screen 
			echo '<div style="overflow: hidden;" id="slider-container">';
			if(mysql_num_rows($result) <= 1) {
			  $countimg++;
			  $content ='<div style="display: none; opacity: 1;height: 530px;" id="banner'."$countimg".'">';
			  $content = "$content"."<img src='../images/profile/default_profile.png' height='60%' usemap='#mail-info' border='0'><br />
			  Your Comments: <input type='text' name='comment' size='48' value =''><br />
			  <textarea rows='8' cols='50' readonly='readonly'>
	 At W3Schools you will find all the Web-building tutorials you need, from basic HTML to advanced XML, SQL, ASP, and PHP. 
	</textarea>";
			  $content = "$content".'</div>';
			  echo "$content";			
			}			
			while($row3 = mysql_fetch_array($result)) {
		  $countimg++;
		  $content ='<div style="display: none; opacity: 1;height: 530px;" id="banner'."$countimg".'">';
		  $content = "$content"."<img src='$row3[name]' height='60%'  usemap='#mail-info' border='0'><br />
		  Your Comments: <input type='text' name='comment' size='48' value =''><br />
		  <textarea rows='8' cols='50' readonly='readonly'>
 At W3Schools you will find all the Web-building tutorials you need, from basic HTML to advanced XML, SQL, ASP, and PHP. 
</textarea>";
		  $content = "$content".'</div>';
		  echo "$content";
		  };
		echo '</div>';	

		
		}
	}
?>		
</center>		
</body>
</html>
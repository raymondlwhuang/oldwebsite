<?php
session_start();
include("../config.php");
$query="SELECT * FROM advertisement where is_active = 1 and expire_date >= NOW() order by id desc";  // query string stored in a variable
$result=mysql_query($query);          // query executed 
echo mysql_error();              // if any error is there that will be printed to the screen 

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Help listing</title>
<style type="text/css">
html, body {
	background-image: url('http://www.todaysluckywinner.com/images/mainbg.jpg');
 }
</style>
</head>
<body>
<?php	
$totalHeight = 0;
while($nt=mysql_fetch_array($result)){
	if($nt['msg_flag'] == 1) {
	$totalHeight = $totalHeight + 200;
	echo "<div style='height:200px;color:yellow;text-align:center;'>	
	$nt[message]
	</div>";
	}
	if($nt['disp_flag'] == 1) {
	$totalHeight = $totalHeight + 200;
	echo "<div style='text-align:center;'>	
	<img src='$nt[display]' height='200px' />
	</div>
	";
	}
}
?>
<script type="text/javascript">var ScrollStep=200, ScrollInterval=5000, WindowPostion=0, ToggleVariable=1, ScrollPosition1=0, ScrollPosition2=-1,upid="",MiniAdjust=4,Ajustment=50;</script>
<script type="text/javascript">var totalHeight = <?php echo "$totalHeight"; ?> </script>
<script type="text/javascript" src="../scripts/AutoScroll.js"></script>
</body>
</html>
	
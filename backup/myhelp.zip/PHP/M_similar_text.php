<?php
$string1 = "raymond";
$string2 = "ray";
similar_text($string1, $string2, $p);
echo "'raymond' and 'ray' are $p% similar";
?>
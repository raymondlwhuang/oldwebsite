<?php
echo 'strrchr("Hello world! this is the world we are living in","world");';
echo "<br/>";
echo strrchr("Hello world! this is the world we are living in","world");
echo "<br/>";
?> 		
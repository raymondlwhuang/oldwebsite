<?php
session_start();
if(@$_SESSION['private'] != "yes")
{
	header('Location: login.php');
	exit();
}
include("../config.php");
include("../inc/GlobalVar.inc.php");
include("../inc/CurrentDateTime.inc.php");
mysql_query("UPDATE user SET last_activity='$now', is_active = 3 WHERE email_address = '$GV_email_address' order by id limit 1");
echo mysql_error();
$b = strtotime($now) - 1800;
$exipred = date('Y-m-d H:i:s',$b);
mysql_query("UPDATE user SET is_active= 1 WHERE last_activity < '$exipred'");

$FriendEmail[$GV_owner_path] = $GV_email_address;
$FriendCount = 0;
$query="SELECT * FROM view_permission where owner_email = '$GV_email_address' group by viewer_email";  // query string stored in a variable
$result=mysql_query($query);          // query executed 
echo mysql_error();              // if any error is there that will be printed to the screen 
while($row2 = mysql_fetch_array($result))
{
	$curr_path = $row2['owner_path'];
	$FriendEmail[$curr_path] = $row2['viewer_email'];
	if($row2['is_active']==3) $TalkStatus[] = 'checked'; else $TalkStatus[] = '';
	$TalkValue[] = $row2['is_active'];
	$queryFriends="SELECT * FROM user where  email_address = '$row2[viewer_email]' and is_active <> 0 LIMIT 1";
	$friend=mysql_query($queryFriends);          // query executed 
	echo mysql_error();
	while($row3 = mysql_fetch_array($friend))
	{
	 $first_name=ucfirst(strtolower($row3['first_name']));
	 $last_name = ucfirst(strtolower($row3['last_name']));
	 $profile_picture[] = $row3['profile_picture'];
	 $name[] = $first_name." ".$last_name;
	 $FriendStat[] = $row3['is_active'];
	} 
	$FriendCount = $FriendCount + 1;

}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<head>
<style type="text/css">
	div#backdrop {
		width:985px;
		margin:auto;
		position:relative;
	}
</style>
<title>Pictures and Videos</title>
<script src="../scripts/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="../scripts/ajaxload.js"></script>
<script>
 $(document).ready(function() {
 	 $("#responsecontainer").load("ShowFriends.php");
   var refreshId = setInterval(function() {
      $("#responsecontainer").load('ShowFriends.php?randval='+ Math.random());
   }, 1000);
   $.ajaxSetup({ cache: false });
});
function SetChat (ChatStatus) {
	if(ChatStatus!=3){
	 document.getElementById('ChatFrame').style.display = 'none';
	}
	else {
	 document.getElementById('ChatFrame').style.display = 'block';
	}
}
function newExcitingAlerts() { 
    var oldTitle = document.title; 
    var msg = "New!"; 
    var timeoutId = setInterval(function() { 
        document.title = document.title == msg ? ' ' : msg; 
    }, 1000); 
    window.onmousemove = function() { 
        clearInterval(timeoutId); 
        document.title = oldTitle; 
        window.onmousemove = null; 
    }; 
} 

</script>
</head>	
</body>
<div id="backdrop" style="display:block;">
<table width="100%">
<tbody>
<tr>
<td width="240" valign="top">
	<iframe src="Friends.php" width="240" height="900" id="Main1" frameborder=0 SCROLLING=no>
	  <p>Your browser does not support iframes.</p>
	</iframe>
</td>
<td valign="top">
	<iframe src="PictureMain.php" width="611" height="535" id="Main2" name="MyBlog"  id="MyBlog" frameborder=0 SCROLLING=no>
	  <p>Your browser does not support iframes.</p>
	</iframe>
</td>
<td width="134" valign="top">
	<iframe src="PublicGroup.php" width="134" height="550" id="Main3" name="Public"  id="Public" frameborder=0 SCROLLING=no>
	  <p>Your browser does not support iframes.</p>
	</iframe>
</td>
</tr>
</tbody>
</table>
</div>
<iframe src="chat.php" height="350" width="445" id="ChatFrame" frameborder=0 SCROLLING=no allowTransparency="false" style="position:fixed;bottom:0px;right:210px;z-index:3;background-color:#FFFFFF;display:block;">
  <p>Your browser does not support iframes.</p>
</iframe>
<div color="darkblue" style="position:fixed;bottom:0px;right:10px;float:right;">

<div id="responsecontainer"></div>
<span style="display:inline-block;">
<div id="maincontent">
<img src='../images/green.png'  width='20' id='picked' />
</div></span>

<select name="MyStatus" border=0 onChange="SetChat(this.value);SendRequest ('../PHP/MyIndicator.php?Indicator='+this.value,'maincontent');">
   <option value="3" >I am Available</option>
   <option value="2" >I am Away</option>
   <option value="4" >I am Busy</option>
   <option value="5" >I am Offline</option>
 </select> 
</div>
</body>
</html>
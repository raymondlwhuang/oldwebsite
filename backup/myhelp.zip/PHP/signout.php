<?php
	session_start();
	include("../config.php");
	include("../inc/GlobalVar.inc.php");
	include("../inc/CurrentDateTime.inc.php");
	$b = strtotime($now) - 1800;
	$exipred = date('Y-m-d H:i:s',$b);
	mysql_query("UPDATE user SET last_activity='$now', is_active = 1 WHERE email_address = '$GV_email_address' order by id limit 1");
	mysql_query("UPDATE user SET is_active= 1 WHERE last_activity < '$exipred'");
	echo mysql_error();	
	mysql_query("UPDATE view_permission SET is_active = 1 WHERE owner_email = '$GV_email_address' and is_active > 1 order by owner_email");
	echo mysql_error();	
	mysql_query("UPDATE view_permission SET is_active = 1 WHERE viewer_email = '$GV_email_address' and is_active > 1 order by viewer_email");
	echo mysql_error();	
	setcookie('member_name', '', time() - 96 * 3600, '/');
	setcookie('user_name', '', time() - 96 * 3600, '/');
	setcookie('member_pass', '', time() - 96 * 3600, '/');
	setcookie ('siteAuth', '', time() - 96 * 3600);
	unset($_COOKIE['member_name']);
	unset($_COOKIE['user_name']);
	unset($_COOKIE['member_pass']);
	unset($_SESSION["username"]);
	unset($_SESSION["private"]);
  
  session_write_close();
  header( "Location: login.php" );
?>  
<frameset rows="*,135"  border="0" framespacing="0">
   <frame src="VideoShow2.php" name="VideoMain" scrolling=yes />
   <frame src="VideoSelect2.php" frameborder=0 scrolling=no />
</frameset>

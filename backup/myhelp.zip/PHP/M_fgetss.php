<?php
$file = fopen("../HTML/countdown.html","r");
echo fgetss($file);
fclose($file);
?> 		
<?php
echo <<<_END
<script type="text/javascript">
document.write('This message is display with the php echo function that is calling the javascript wirte function');
</script>
_END;
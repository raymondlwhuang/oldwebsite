<frameset rows="*,35"  border="0" framespacing="0">
   <frame src="VideoShow.php" name="VideoMain" scrolling=no />
   <frame src="VideoSelect.php" frameborder=0 scrolling=no />
</frameset>

<?php
$path="../PHP";
chdir($path);
echo getcwd();
echo "<br/>";
$path="../PHP/";
chdir($path);
echo getcwd();

?>
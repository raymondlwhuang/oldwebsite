echo chunk_split('FF99FF', 2, ':'); 
echo "</br>";
echo substr(chunk_split('FF99FF', 2, ':'),0,8);
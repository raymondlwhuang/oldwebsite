<?php
print_r(file("../txt/MySpending.txt"));
?>
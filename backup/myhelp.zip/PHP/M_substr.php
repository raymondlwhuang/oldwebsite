<?php
    // both lines will output the 3rd character
    echo '$my_string = "this is a testing";';
    echo "<br/>";
    $my_string = "this is a testing";
    echo 'substr($my_string, 2, 1);';
    echo "<br/>";
    echo substr($my_string, 2, 1);
    echo "<br/>";
    echo '$my_string{2}; ';
    echo "<br/>";
    echo $my_string{2};
    echo "<br/>";

?>
<?php $brwsr = strtolower($_SERVER['HTTP_USER_AGENT']); 
echo "This is the browser your current running: ".$brwsr;
?>
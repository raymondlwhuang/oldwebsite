<?php
echo filegroup("date.txt");
?> 		
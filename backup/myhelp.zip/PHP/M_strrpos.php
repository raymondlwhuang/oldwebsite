<?php
echo 'strrpos("Hello world!","wo");';
echo "<br/>";
echo strrpos("Hello world!","wo");
echo "<br/>";
?>
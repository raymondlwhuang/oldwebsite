<?php
$path = "../PHP/ResultDisp.php";

//Show filename with file extension
echo basename($path) ."<br/>";

//Show filename without file extension
echo basename($path,".php");
?> 		
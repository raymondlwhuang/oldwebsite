<?php
echo 'strtolower("Hello WORLD.");';
echo "<br/>";
echo strtolower("Hello WORLD.");
?> 		
<?php
echo "string '2Hello world!' is less than: '10Hello world!'";
echo "<br />";
echo strnatcasecmp("2Hello world!","10Hello world!");
echo "<br />";
echo "string '10Hello world!' is greater than: '2Hello world!'";
echo "<br />";
echo strnatcasecmp("10Hello world!","2Hello world!");
?> 		
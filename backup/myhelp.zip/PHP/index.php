<?php
session_start();
if(@$_SESSION['private'] != "yes")
{
	header('Location: login.php');
	exit();
}
include("../config.php");
include("../inc/GlobalVar.inc.php");
include("../inc/CurrentDateTime.inc.php");
mysql_query("UPDATE user SET last_activity='$now' WHERE email_address = '$GV_email_address' order by id limit 1");
echo mysql_error();
$b = strtotime($now) - 1800;
$exipred = date('Y-m-d H:i:s',$b);
mysql_query("UPDATE user SET is_active= 1 WHERE last_activity < '$exipred'");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<head>
<style type="text/css">
	div#backdrop {
		width:985px;
		margin:auto;
		position:relative;
	}
</style>
<title>Pictures and Videos</title>
<script src="../scripts/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="../scripts/ajaxload.js"></script>
</head>	
</body>
<div id="backdrop" style="display:block;">
<table width="100%">
<tbody>
<tr>
<td width="240" valign="top">
	<iframe src="Friends.php" width="240" height="900" id="Main1" frameborder=0 SCROLLING=no>
	  <p>Your browser does not support iframes.</p>
	</iframe>
</td>
<td valign="top">
	<iframe src="PictureMain.php" width="611" height="535" id="Main2" name="MyBlog"  id="MyBlog" frameborder=0 SCROLLING=no>
	  <p>Your browser does not support iframes.</p>
	</iframe>
</td>
<td width="134" valign="top">
	<iframe src="PublicGroup.php" width="134" height="550" id="Main3" name="Public"  id="Public" frameborder=0 SCROLLING=no>
	  <p>Your browser does not support iframes.</p>
	</iframe>
</td>
</tr>
</tbody>
</table>
</div>
<iframe src="chat.php" height="400" width="645" id="ChatFrame" frameborder=0 SCROLLING=no allowTransparency="false" style="position:fixed;bottom:0px;right:0px;z-index:3;background-color:#FFFFFF;display:block;">
  <p>Your browser does not support iframes.</p>
</iframe>
</body>
</html>
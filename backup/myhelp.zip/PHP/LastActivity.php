<?php
include("../config.php");
include("../inc/GlobalVar.inc.php");
include("../inc/CurrentDateTime.inc.php");

mysql_query("UPDATE user SET last_activity='$now' WHERE email_address = '$GV_email_address' order by id limit 1");
$b = strtotime($now) - 1800;
$exipred = date('Y-m-d H:i:s',$b);
mysql_query("UPDATE user SET is_active= 1 WHERE last_activity < '$exipred'");
echo mysql_error();

?>
<html>
<body>
<?php
$str = "         Hello World!               ";
echo "<pre>";
echo "Without trim: " . $str;
echo "<br />";
echo "With trim: " . trim($str);
echo "</pre>";
?>
<body>
<html>
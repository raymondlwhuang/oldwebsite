<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Pass Variable To Javascript</title>
</head>
<body>
<form class="cmxform" name="signup" id="signup_form" method="post" action="../PHP/PassVarToJavascript2.php">
<table width="860" border="0" cellspacing="0" cellpadding="0">
	  <tr>
		<td align="right"><label for="first_name">First Name:</label></td>
		<td><input name="first_name" type="text" class="FieldPubreq" id="first_name" minlength="2"></td>
	  </tr>
	  <tr>
		<td align="right"><label for="last_name">Last Name:</label></td>
		<td><input name="last_name" type="text" class="FieldPubreq" id="last_name" minlength="2"></td>
	  </tr>
</table>
<input type="submit" name="submit" value="submit">
</form>
</body>
</html>
		
<?php
echo strstr("Hello world!","world");
?> 		
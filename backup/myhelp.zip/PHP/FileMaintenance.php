<frameset cols="155,*"  border="0" framespacing="0">
   <frame src="RemovePicture.php" name="VideoMain" scrolling=yes />
   <frame src="../HTML/FileMaintenance.html" frameborder=0 scrolling=no />
</frameset>

<?php
session_start();
include("../config.php");
include("../inc/GlobalVar.inc.php");
include("../inc/CurrentDateTime.inc.php");
$b = strtotime($now) - 1800;
$exipred = date('Y-m-d H:i:s',$b);
mysql_query("UPDATE user SET last_activity='$now' WHERE email_address = '$GV_email_address' order by id limit 1");
mysql_query("UPDATE user SET is_active= 1 WHERE last_activity < '$exipred'");
echo mysql_error();

IF(isset($_GET['email']))
{
	$viewer_email = mysql_real_escape_string($_GET['email']);
	$queryFriend="SELECT * FROM view_permission where  owner_email = '$GV_email_address' and viewer_email = '$viewer_email' order by id LIMIT 1";
	$friend=mysql_query($queryFriend);          // query executed 
	echo mysql_error();
	while($row = mysql_fetch_array($friend))
	{
	 $CurrStat = $row['is_active'];
	} 	
	if($CurrStat == 3) $activate = 1; else $activate = 3;	
	mysql_query("UPDATE view_permission SET is_active=$activate WHERE owner_email = '$GV_email_address' and viewer_email = '$viewer_email'");
	echo mysql_error();
}

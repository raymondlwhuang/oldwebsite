<?php
echo 'Only the superuser may change the owner of a file.';	
chown("date.txt","charles")
?> 	
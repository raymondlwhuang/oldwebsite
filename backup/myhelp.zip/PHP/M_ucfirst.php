<?php
echo 'ucfirst("hello world");';
echo "<br/>";
echo ucfirst("hello world");
echo "<br/>";
?>
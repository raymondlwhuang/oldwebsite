<?php
echo 'print_r(scandir("../images"));';
echo "<br/>";
print_r(scandir("../images"));
echo "<br/>";
?> 		
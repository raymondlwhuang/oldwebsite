<?php
$homepage = file_get_contents('../HTML/countdown.html');
echo $homepage;
?>
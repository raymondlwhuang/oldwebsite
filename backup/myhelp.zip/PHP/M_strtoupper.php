<?php
echo 'strtoupper("Hello WORLD!");';
echo "<br/>";
echo strtoupper("Hello WORLD!");
?> 		
<?php
echo 'ucwords("hello world");';
echo "<br/>";
echo ucwords("hello world");
?> 		
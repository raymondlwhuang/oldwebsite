<?php
require_once '../config.php';
require_once('../PHP/sethash.php');
include("../inc/GlobalVar.inc.php");
$MyID = '|' . $GV_id . '|';
//returning the last 15 messages
	$vRes = mysql_query("SELECT * FROM `s_chat_messages` where talk_to like '%$MyID%' ORDER BY `id` DESC LIMIT 15");

	$sMessages = '';
	$Msg_Output = '';
	// collecting list of messages
	if ($vRes) {
		while($aMessages = mysql_fetch_array($vRes)) {
				
				$GetMsg = mysql_query("SELECT * FROM talk_message WHERE id = $aMessages[msg_id] LIMIT 1");
				while($row4 = mysql_fetch_array($GetMsg))
				{
						 $Msg_Output = newdecode($row4['message']);
				}				
		
		
			//$sWhen = date("M j h:i:s A", $aMessages['msg_time']);
			$sWhen = $aMessages['msg_time'];
			$sMessages = '<div ><font style="font-size:xx-small;">' . $aMessages['user'] . '<span>(' . $sWhen . ')</span>'. ': ' . '<font style="font-size:medium;color:green;">'.$Msg_Output.'</font>'.' </div>'.$sMessages;
		}
	} else {
		$sMessages = 'DB error, create SQL table before';
	}

	mysql_close($link);
	echo $sMessages;
?>
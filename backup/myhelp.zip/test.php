<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd"> 
<html>
<title>
</title>
<head>
<body>
<video src="http://raymondlwhuang.com/videos/movie.mp4" width="111" height="81" autoplay=true controls autobuffer></video>
<video src="http://raymondlwhuang.com/videos/t1.mp4" width="111" height="81" autoplay=true autobuffer loop>testing</video>
<video src="http://raymondlwhuang.com/videos/t2.mp4" width="111" height="81" autoplay=true autobuffer loop></video>
<video src="http://raymondlwhuang.com/videos/t3.mp4" width="111" height="81" autoplay=true autobuffer loop></video>
<video src="http://raymondlwhuang.com/videos/t4.mp4" width="111" height="81" autoplay=true autobuffer loop></video>
<video src="http://raymondlwhuang.com/videos/t5.mp4" width="111" height="81" autoplay=true autobuffer loop></video>
<video src="http://raymondlwhuang.com/videos/t6.mp4" width="111" height="81" autoplay=true autobuffer loop></video>
<video src="http://raymondlwhuang.com/videos/t7.mp4" width="111" height="81" autoplay=true autobuffer loop></video>
<video src="http://raymondlwhuang.com/videos/t8.mp4" width="111" height="81" autoplay=true autobuffer loop></video>
<video src="http://raymondlwhuang.com/videos/t9.mp4" width="111" height="81" autoplay=true autobuffer loop></video>
</body>
</html>
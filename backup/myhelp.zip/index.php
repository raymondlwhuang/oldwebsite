<?php 
header( "Location: PHP/login.php" );
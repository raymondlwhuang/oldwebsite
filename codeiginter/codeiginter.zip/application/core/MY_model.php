<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class MY_Model extends CI_Model
{

	public $table;
	public function __construct()
	{
		parent::__construct();
		$this->table = get_Class($this);
		$this->load->database();
	}
	function _required($required, $data) {
		foreach($required as $field) if(!isset($data[$field])) return false;
		return true;
	}

	function _default($defaults, $options) {
		return array_merge($defaults, $options);
	}	
	
	public function save($options = array())
	{
		// required values
		if(!$this->_required(array('data'), $options)) return false;
		$options = $this->_default(array('tablename' => ''), $options);
		if($options['tablename']=="")
		{
			$options['tablename'] = $this->table;
		}
		$op = 'update';
		$keyExists = FALSE;
		$fields = $this->db->field_data($options['tablename']);
		foreach ($fields as $field)
		{
			if($field->primary_key==1)
			{
				$keyExists = TRUE;
				if(isset($options['data'][$field->name]))
				{
					$this->db->where($field->name, $options['data'][$field->name]);
				}
				else
				{
					$op = 'insert';
				}
			}
		}
	 
		if($keyExists && $op=='update')
		{
			$this->db->set($options['data']);
			$this->db->update($options['tablename']);
			if($this->db->affected_rows()==1)
			{
				return $this->db->affected_rows();
			}
		}
	 
		$this->db->insert($options['tablename'],$options['data']);
	 
		return $this->db->affected_rows();
	 
	}
	 
	function search($options = array())
	{
		$options = $this->_default(array('tablename' => '','conditions'=> NULL,'limit'=>500,'offset'=>0), $options);
		if($options['tablename']=="")
		{
			$options['tablename'] = $this->table;
		}
		if($options['conditions'] != NULL)
			$this->db->where($options['conditions']);
	 
		$query = $this->db->get($options['tablename'],$limit,$offset=0);
		return $query->result();
	}
	 
	function insert($options = array())
	{
		if(!$this->_required(array('data'), $options)) return false;
		$options = $this->_default(array('tablename' => ''), $options);
		if($options['tablename']=="")
			$options['tablename'] = $this->table;
		$this->db->insert($options['tablename'],$options['data']);
		return $this->db->affected_rows();
	}
	 
	function update($options = array())
	{
		if(!$this->_required(array('data'), $options)) return false;
		$options = $this->_default(array('tablename' => ''), $options);
		if($options['tablename']=="")
			$options['tablename'] = $this->table;
		$this->db->where($options['conditions']);
		$this->db->update($options['tablename'],$options['data']);
		return $this->db->affected_rows();
	}
	 
	function delete($options = array())
	{
		if(!$this->_required(array('conditions'), $options)) return false;
		$options = $this->_default(array('tablename' => ''), $options);
		if($options['tablename']=="")
			$options['tablename'] = $this->table;
		$this->db->where($options['conditions']);
		$this->db->delete($options['tablename']);
		return $this->db->affected_rows();
	}	
		
}
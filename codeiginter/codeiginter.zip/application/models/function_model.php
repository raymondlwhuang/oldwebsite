<?php

class Function_model extends CI_model {

}
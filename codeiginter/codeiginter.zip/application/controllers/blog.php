<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Blog extends CI_Controller {
	public function __construct() 
	{ 
		parent::__construct(); 
		session_start();
		$cookie_name = 'siteAuth';
		$cookie_time = 2592000; // 30 days
		ini_set('display_errors', 'On'); //off
		error_reporting(-1);	// 0
		define('MP_DB_DEBUG', true);  // false
		if(!isset($_SESSION['username'])) $this->load->view('autologin.php');
		/*
		if (isset($_SESSION["page"]) && $_SESSION["page"]== "HER") {
			unset($_SESSION["page"]);
			$this->load->view('top');
			$this->load->view('HERecorder');
			$this->load->view('footer');
		}
		elseif (isset($_SESSION["page"]) && $_SESSION["page"] == "HELP") {
			unset($_SESSION["page"]);
			$this->load->view('top');
			$this->load->view('ResultDisp');
			$this->load->view('footer');
		}	*/
	} 
	 
	public function index()
	{
		$orgurl= explode("/",rtrim($_SERVER['REQUEST_URI'],"/"));
		$pieces = explode("?", $orgurl[1]);
		$url=$pieces[0];
		$header='header';
		$thisurl='index';
		$footer='footer';
		$data=array();
		if(isset($pieces[1])) {
			$pieces2 = explode("=", $pieces[1]);
			for($i=0;$i<count($pieces2);$i+=2){
				$data[$pieces2[$i]]=$pieces2[$i+1];
			}
		}
		if(isset($url) && $url!="") $thisurl=$url;
		echo $thisurl;
		die;
		if($thisurl=='index' || $thisurl=='index.php') {
		
		}
		$this->load->view($header,$data);		
		$this->load->view($thisurl,$data);		
		$this->load->view($footer,$data);		
//		$fields = $this->db->field_data('user');
		
//		$this->load->model("user");
//		$condition=array('id >' =>2);
//		$data=array('name' => 3);
//		$test=$this->user->update(array('data'=>$data,'conditions'=>$condition));
//		echo $test;
	//	$this->load->view('test',$data);
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */